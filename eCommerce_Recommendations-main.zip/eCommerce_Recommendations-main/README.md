# eCommerce_Recommendations



Dataset for word2vec recommendation system tutorial available here: https://archive.ics.uci.edu/ml/machine-learning-databases/00352/
